document.write('<scr'+'ipt src="//s1.lemde.fr/min/medias/web/4e079d767f7665eed53e4592229e0c55/js/lmd/core/mobile-redirect.js"></scr'+'ipt>');
document.write('<scr'+'ipt src="//s1.lemde.fr/conf.js"></scr'+'ipt>');
document.write('<scr'+'ipt src="//s1.lemde.fr/min/medias/web/168f2d728830a1c3aab8bef8917179e7/js/lmd/module/abonnes/redirection.js"></scr'+'ipt>');