Please refer to [GUIDELINES.md](./GUIDELINES.md) for the updated contributor guidelines.
